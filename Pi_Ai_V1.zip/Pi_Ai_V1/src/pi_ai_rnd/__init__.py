"""
pi_ai_rnd package

V1 scope:
- C2-only live viewer + person bbox overlay (OpenCV window)
"""

__version__ = "V1"
